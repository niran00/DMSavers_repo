$("#jclick").click(function(){
  alert("Jquery is working");
});



function myFunction() {
  alert('confirmed Javascript wroks ');
}
